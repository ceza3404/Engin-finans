package com.engin.finans.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Category(val name:String, val icon:String)

@Composable
fun EnginFinansApp() {
    var selected by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var categories by remember { mutableStateOf(listOf(
        Category("Faturalar","🧾"), Category("Çocuklar","👦"), Category("Mutfak","🍽️"),
        Category("Bankalar","🏦"), Category("Kira","🏠"), Category("TOKİ","🏢"),
        Category("Araç & Benzin","🚗"), Category("Yol","🛣️"),
        Category("Engin","👨"), Category("Ebru","👩")
    )) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF4DD0E1),
        secondary = Color(0xFF81C784),
        surface = Color(0xFF171B23),
        background = Color(0xFF0D1016)
    )) {
        Scaffold(
            containerColor = Color(0xFF0D1016),
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF151922)) {
                    listOf("Ana Sayfa","İşlemler","Analiz","Araç","Ayarlar").forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = selected == i,
                            onClick = { selected = i },
                            icon = { Icon(
                                when(i){0->Icons.Default.Home;1->Icons.Default.List;2->Icons.Default.PieChart;3->Icons.Default.DirectionsCar;else->Icons.Default.Settings},
                                null
                            ) },
                            label = { Text(t) }
                        )
                    }
                }
            }
        ) { pad ->
            when(selected) {
                0 -> Home(pad, categories)
                1 -> Transactions(pad)
                2 -> Analysis(pad)
                3 -> Vehicle(pad)
                else -> Settings(pad, categories, {showAdd=true}, {c -> categories=categories.filterNot {it.name==c.name}})
            }
        }

        if(showAdd) {
            var name by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest={showAdd=false},
                title={Text("Kategori Ekle")},
                text={TextField(value=name,onValueChange={name=it},label={Text("Kategori adı")})},
                confirmButton={TextButton(onClick={
                    if(name.isNotBlank()) categories=categories+Category(name,"📁")
                    showAdd=false
                }){Text("Ekle")}},
                dismissButton={TextButton(onClick={showAdd=false}){Text("İptal")}}
            )
        }
    }
}

@Composable fun Header(title:String, sub:String) {
    Column(Modifier.padding(20.dp)) {
        Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold)
        Text(sub,color=Color.LightGray,modifier=Modifier.padding(top=4.dp))
    }
}
@Composable fun MoneyCard(title:String,value:String,icon:String,accent:Color) {
    Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp),
        colors=CardDefaults.cardColors(containerColor=Color(0xFF181D27)),
        shape=RoundedCornerShape(20.dp)) {
        Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
            Text(icon,fontSize=30.sp)
            Column(Modifier.padding(start=14.dp)) {
                Text(title,color=Color.LightGray)
                Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=accent)
            }
        }
    }
}
@Composable fun Home(pad:PaddingValues,categories:List<Category>) {
    LazyColumn(Modifier.padding(pad)) {
        item { Header("Engin Finans","Ekim 2026 • Mali durumun") }
        item { MoneyCard("Maaş / Gelir","₺0,00","💰",Color(0xFF81C784)) }
        item { MoneyCard("Toplam Gider","₺0,00","🔴",Color(0xFFFF8A80)) }
        item { MoneyCard("Aylık Kalan","₺0,00","🟢",Color(0xFF4DD0E1)) }
        item { Text("Kategoriler",fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp,18.dp,20.dp,6.dp)) }
        items(categories) { c ->
            Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=5.dp),
                colors=CardDefaults.cardColors(containerColor=Color(0xFF181D27))) {
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(c.icon,fontSize=25.sp); Text(c.name,fontSize=17.sp,modifier=Modifier.padding(start=14.dp))
                }
            }
        }
    }
}
@Composable fun Transactions(pad:PaddingValues) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        Header("İşlemler","Gelir ve gider kayıtları")
        Button(onClick={},modifier=Modifier.padding(horizontal=16.dp).fillMaxWidth()) { Text("＋ Gelir / Gider Ekle") }
        Text("Henüz işlem yok.",modifier=Modifier.padding(20.dp),color=Color.LightGray)
    }
}
@Composable fun Analysis(pad:PaddingValues) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        Header("Analiz","Haftalık ve aylık finans görünümü")
        MoneyCard("Bu ay gelir","₺0,00","📈",Color(0xFF81C784))
        MoneyCard("Bu ay harcama","₺0,00","📉",Color(0xFFFF8A80))
        MoneyCard("Kalan","₺0,00","💎",Color(0xFF4DD0E1))
        Text("📊 Gelir – gider grafiği",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp))
        Text("Grafik altyapısı hazır; işlemler eklendikçe haftalık, aylık ve son 6 ay analizi burada gösterilecek.",modifier=Modifier.padding(horizontal=20.dp),color=Color.LightGray)
    }
}
@Composable fun Vehicle(pad:PaddingValues) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        Header("Araç","Hyundai i20 giderleri")
        MoneyCard("Benzin","₺0,00","⛽",Color(0xFFFFD54F))
        MoneyCard("Bakım / servis","₺0,00","🔧",Color(0xFF90CAF9))
        MoneyCard("Toplam araç gideri","₺0,00","🚗",Color(0xFF4DD0E1))
    }
}
@Composable fun Settings(pad:PaddingValues,cats:List<Category>,add:()->Unit,del:(Category)->Unit) {
    Column(Modifier.padding(pad).fillMaxSize()) {
        Header("Ayarlar","Kategori ve uygulama yönetimi")
        Button(onClick=add,modifier=Modifier.padding(horizontal=16.dp).fillMaxWidth()) { Text("＋ Kategori Ekle") }
        Text("Kategori Sil",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(20.dp,22.dp,20.dp,8.dp))
        cats.forEach { c ->
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                Text(c.icon); Text(c.name,Modifier.weight(1f).padding(start=12.dp))
                IconButton(onClick={del(c)}) { Icon(Icons.Default.Delete,"Sil") }
            }
        }
    }
}
