# Engin Finans – Android

Bu proje, istenen gelir-gider uygulamasının temiz Android/Jetpack Compose başlangıç projesidir.

İçerik:
- Gelir, gider, maaş ve kalan para kartları
- Faturalar, çocuklar, mutfak, bankalar, kira, TOKİ, araç/benzin, yol, Engin, Ebru kategorileri
- Kategori ekleme ve silme
- Haftalık/aylık analiz ekranı için altyapı
- Araç/benzin ekranı
- Türkçe modern koyu/dijital arayüz

APK oluşturma:
1. Android Studio ile klasörü açın.
2. Gradle senkronizasyonunu tamamlayın.
3. Build > Generate App Bundles or APKs > Generate APKs seçin.
4. Oluşan APK'yı Android telefona aktararak kurabilirsiniz.

Not: Bu sohbet ortamında Android SDK/Gradle derleme ortamı bulunmadığından burada imzalı APK üretilemiyor. Proje APK derlemeye hazır kaynak olarak verilmektedir.
